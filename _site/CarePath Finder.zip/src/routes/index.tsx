import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  ALL_LANGUAGES,
  ALL_SPECIALTIES,
  hospitals,
  rankHospitals,
  type Priority,
} from "@/lib/hospitals";
import { usePreferences } from "@/lib/preferences";
import { t } from "@/lib/i18n";
import { EmergencyBanner } from "@/components/EmergencyBanner";
import { MapPanel } from "@/components/MapPanel";
import { HospitalCard } from "@/components/HospitalCard";
import { ReportDialog } from "@/components/ReportDialog";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CarePath Navigator — Real-time UK hospital queue estimator" },
      {
        name: "description",
        content:
          "Find the right UK hospital based on predicted wait times, distance, specialties and language support. Not a diagnostic tool — for emergencies call 999.",
      },
      { property: "og:title", content: "CarePath Navigator" },
      {
        property: "og:description",
        content:
          "Real-time hospital queue estimator and finder for the United Kingdom.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const [prefs, updatePrefs] = usePreferences();
  const [activeId, setActiveId] = useState<string | undefined>(hospitals[0]?.id);
  const [overrideContinue, setOverrideContinue] = useState<Record<string, boolean>>({});
  const [reportOpen, setReportOpen] = useState(false);
  const lang = prefs.uiLang;

  // Simulate load-balancing: penalise the most popular pick to redistribute traffic.
  const loadBalanceFactor = useMemo(() => {
    const top = hospitals[0]?.id;
    return top ? { [top]: 0.15 } : {};
  }, []);

  const visibleHospitals = useMemo(() => {
    return hospitals.filter((h) => {
      if (
        prefs.preferredSpecialty &&
        !h.specialties.includes(prefs.preferredSpecialty)
      )
        return false;
      if (
        prefs.preferredLanguage &&
        !h.languages.some(
          (l) =>
            l.language === prefs.preferredLanguage &&
            l.level !== "No Verified Language Support",
        )
      )
        return false;
      return true;
    });
  }, [prefs.preferredSpecialty, prefs.preferredLanguage]);

  const ranked = useMemo(
    () =>
      rankHospitals(visibleHospitals, {
        priority: prefs.priority,
        preferredLanguage: prefs.preferredLanguage,
        preferredSpecialty: prefs.preferredSpecialty,
        loadBalanceFactor,
      }),
    [visibleHospitals, prefs, loadBalanceFactor],
  );

  return (
    <div className="flex min-h-screen flex-col bg-background font-sans text-foreground">
      <EmergencyBanner lang={lang} onLangChange={(c) => updatePrefs({ uiLang: c })} />

      <main className="mx-auto flex w-full max-w-7xl flex-1 flex-col md:flex-row">
        <MapPanel
          hospitals={hospitals}
          activeId={activeId}
          onSelect={setActiveId}
          lang={lang}
        />

        <section className="animate-list w-full space-y-6 overflow-y-auto p-4 md:w-1/2 md:p-6 lg:w-2/5">
          {/* Header & priority toggle */}
          <div className="space-y-4">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                CarePath Navigator · UK
              </p>
              <h1 className="mt-1 font-display text-2xl tracking-tight">
                {t(lang, "nearbyFacilities")}
              </h1>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <PriorityToggle
                value={prefs.priority}
                onChange={(p) => updatePrefs({ priority: p })}
                lang={lang}
              />
              <button
                onClick={() => setReportOpen(true)}
                className="rounded-md border border-border bg-card px-3 py-1.5 text-[11px] font-semibold tracking-tight hover:bg-foreground hover:text-primary-foreground"
              >
                + {t(lang, "reportWait")}
              </button>
            </div>

            {/* Filters */}
            <div className="grid grid-cols-2 gap-3">
              <SelectField
                label={t(lang, "filterSpecialty")}
                value={prefs.preferredSpecialty ?? ""}
                onChange={(v) =>
                  updatePrefs({ preferredSpecialty: v || undefined })
                }
                options={[
                  { value: "", label: t(lang, "any") },
                  ...ALL_SPECIALTIES.map((s) => ({ value: s, label: s })),
                ]}
              />
              <SelectField
                label={t(lang, "filterLanguage")}
                value={prefs.preferredLanguage ?? ""}
                onChange={(v) =>
                  updatePrefs({ preferredLanguage: v || undefined })
                }
                options={[
                  { value: "", label: t(lang, "any") },
                  ...ALL_LANGUAGES.map((l) => ({ value: l, label: l })),
                ]}
              />
            </div>
          </div>

          {/* Results */}
          <div className="space-y-4">
            {ranked.map((r, idx) => (
              <HospitalCard
                key={r.hospital.id}
                ranked={
                  overrideContinue[r.hospital.id]
                    ? { ...r, rationale: "Acknowledged warning — proceeding to facility details." }
                    : r
                }
                index={idx}
                isTop={idx === 0}
                lang={lang}
                onContinue={(id) =>
                  setOverrideContinue((m) => ({ ...m, [id]: true }))
                }
              />
            ))}
            {ranked.length === 0 && (
              <p className="rounded-md border border-dashed border-border bg-card p-4 text-sm text-muted-foreground">
                No facilities match the current filters.
              </p>
            )}
          </div>

          {/* Footer protocol info */}
          <footer className="space-y-3 border-t border-border pt-6">
            <h4 className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              Protocol information
            </h4>
            <Row label="Prediction model" value="XGBoost · 15 min job" />
            <Row label="Data refresh" value="≤ 5 minutes" />
            <Row label="Last calibrated" value="22 Oct 2024" />
            <Row label="MAE vs 35 obs" value="±12% (within target)" />
            <p className="pt-2 text-[11px] leading-relaxed text-muted-foreground">
              {t(lang, "notDiagnostic")} Emergency: <strong className="text-brand-red">999</strong>{" "}
              · Non-urgent advice: <strong>NHS 111</strong>.
            </p>
          </footer>
        </section>
      </main>

      <ReportDialog
        hospitals={hospitals}
        lang={lang}
        open={reportOpen}
        onClose={() => setReportOpen(false)}
      />
    </div>
  );
}

function PriorityToggle({
  value,
  onChange,
  lang,
}: {
  value: Priority;
  onChange: (p: Priority) => void;
  lang: string;
}) {
  return (
    <div className="inline-flex rounded-md bg-surface p-1" role="group" aria-label="Priority">
      {(["fastest", "closest"] as const).map((opt) => (
        <button
          key={opt}
          onClick={() => onChange(opt)}
          aria-pressed={value === opt}
          className={[
            "rounded-[4px] px-3 py-1 text-xs font-semibold transition-colors",
            value === opt
              ? "bg-card text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground",
          ].join(" ")}
        >
          {t(lang, opt)}
        </button>
      ))}
    </div>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <label className="block">
      <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-md border border-border bg-card px-2.5 py-2 text-xs font-medium"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-xs">
      <span>{label}</span>
      <span className="font-mono text-muted-foreground">{value}</span>
    </div>
  );
}
