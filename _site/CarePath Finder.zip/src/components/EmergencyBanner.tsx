import { SUPPORTED_UI_LANGUAGES } from "@/lib/hospitals";
import { t } from "@/lib/i18n";

interface Props {
  lang: string;
  onLangChange: (code: string) => void;
}

export function EmergencyBanner({ lang, onLangChange }: Props) {
  return (
    <header
      role="alert"
      className="animate-header sticky top-0 z-50 flex items-center justify-between gap-4 bg-brand-red px-4 py-3 text-primary-foreground"
    >
      <div className="flex min-w-0 items-center gap-3">
        <span className="size-2 shrink-0 animate-pulse rounded-full bg-primary-foreground" />
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] sm:text-xs">
          {t(lang, "emergencyBadge")}
        </span>
      </div>
      <p className="truncate text-center text-xs font-semibold tracking-tight sm:text-sm">
        {t(lang, "emergencyMessage")}
      </p>
      <label className="ml-2 flex shrink-0 items-center gap-2 text-[11px] font-mono uppercase tracking-wider">
        <span className="sr-only">UI language</span>
        <select
          aria-label="Interface language"
          value={lang}
          onChange={(e) => onLangChange(e.target.value)}
          className="rounded border border-primary-foreground/30 bg-brand-red px-2 py-1 text-[11px] font-medium focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-foreground"
        >
          {SUPPORTED_UI_LANGUAGES.map((l) => (
            <option key={l.code} value={l.code} className="text-foreground">
              {l.label}
            </option>
          ))}
        </select>
      </label>
    </header>
  );
}
