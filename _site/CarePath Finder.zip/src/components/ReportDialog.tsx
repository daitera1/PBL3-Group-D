import { useState } from "react";
import type { Hospital } from "@/lib/hospitals";
import { t } from "@/lib/i18n";

interface Props {
  hospitals: Hospital[];
  lang: string;
  open: boolean;
  onClose: () => void;
}

export function ReportDialog({ hospitals, lang, open, onClose }: Props) {
  const [hospitalId, setHospitalId] = useState(hospitals[0]?.id ?? "");
  const [waitMinutes, setWaitMinutes] = useState("");
  const [submitted, setSubmitted] = useState(false);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="report-title"
      className="fixed inset-0 z-[60] flex items-center justify-center bg-foreground/30 p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-xl border border-border bg-card p-5 shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          Anonymous crowdsourced report
        </p>
        <h2 id="report-title" className="mt-1 font-display text-xl tracking-tight">
          {t(lang, "reportWait")}
        </h2>
        <p className="mt-1 text-xs text-muted-foreground">
          Reports feed the historical data pipeline. They do not directly change the served prediction.
        </p>

        {submitted ? (
          <div className="mt-4 rounded-md border border-brand-green/30 bg-brand-green-soft p-3 text-sm text-brand-green">
            {t(lang, "reportThanks")}
          </div>
        ) : (
          <form
            className="mt-4 space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              setSubmitted(true);
            }}
          >
            <label className="block text-xs font-medium">
              Facility
              <select
                value={hospitalId}
                onChange={(e) => setHospitalId(e.target.value)}
                className="mt-1 w-full rounded-md border border-border bg-card px-3 py-2 text-sm"
              >
                {hospitals.map((h) => (
                  <option key={h.id} value={h.id}>
                    {h.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-xs font-medium">
              Observed wait (minutes)
              <input
                type="number"
                min={0}
                max={600}
                value={waitMinutes}
                onChange={(e) => setWaitMinutes(e.target.value)}
                required
                className="mt-1 w-full rounded-md border border-border bg-card px-3 py-2 text-sm"
              />
            </label>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="rounded-md border border-border bg-card px-3 py-2 text-xs font-medium"
              >
                {t(lang, "cancel")}
              </button>
              <button
                type="submit"
                className="rounded-md bg-foreground px-3 py-2 text-xs font-semibold text-primary-foreground"
              >
                Submit anonymously
              </button>
            </div>
          </form>
        )}

        {submitted && (
          <div className="mt-4 text-right">
            <button
              onClick={() => {
                setSubmitted(false);
                onClose();
              }}
              className="rounded-md border border-border bg-card px-3 py-2 text-xs font-medium"
            >
              Close
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
