import mapImage from "@/assets/london-map.jpg";
import type { Hospital } from "@/lib/hospitals";
import { t } from "@/lib/i18n";

interface Props {
  hospitals: Hospital[];
  activeId?: string;
  onSelect: (id: string) => void;
  lang: string;
}

const dotByCongestion = {
  low: "bg-brand-green ring-brand-green",
  moderate: "bg-brand-amber ring-brand-amber",
  high: "bg-brand-red ring-brand-red",
} as const;

export function MapPanel({ hospitals, activeId, onSelect, lang }: Props) {
  return (
    <section
      className="relative w-full md:sticky md:top-[52px] md:h-[calc(100vh-52px)] md:w-1/2 lg:w-3/5"
      aria-label={t(lang, "liveMap")}
    >
      <div className="relative h-[44vh] w-full overflow-hidden bg-surface md:h-full">
        <img
          src={mapImage}
          alt=""
          width={1280}
          height={1600}
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-background/30" aria-hidden />

        {/* Pins */}
        <div className="absolute inset-0">
          {hospitals.map((h) => {
            const isActive = h.id === activeId;
            return (
              <button
                key={h.id}
                type="button"
                onClick={() => onSelect(h.id)}
                aria-label={`${h.name}, ${h.facilityType}, congestion ${h.congestion}`}
                className={[
                  "group absolute -translate-x-1/2 -translate-y-1/2 rounded-full p-1 transition-transform",
                  isActive ? "scale-110" : "hover:scale-110",
                ].join(" ")}
                style={{ left: `${h.mapX}%`, top: `${h.mapY}%` }}
              >
                <span
                  className={[
                    "block size-3 rounded-full ring-2 ring-offset-2 ring-offset-background",
                    dotByCongestion[h.congestion],
                  ].join(" ")}
                />
                <span
                  className={[
                    "pointer-events-none absolute left-1/2 top-full mt-2 -translate-x-1/2 whitespace-nowrap rounded-md border border-border bg-card px-2 py-1 font-mono text-[10px] font-medium shadow-sm transition-opacity",
                    isActive ? "opacity-100" : "opacity-0 group-hover:opacity-100",
                  ].join(" ")}
                >
                  {h.name}
                </span>
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 rounded-md border border-border bg-card/90 p-3 backdrop-blur-sm">
          <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            {t(lang, "liveMap")}
          </p>
          <ul className="space-y-1.5 text-[11px]">
            <li className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-brand-green" /> Low congestion
            </li>
            <li className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-brand-amber" /> Moderate
            </li>
            <li className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-brand-red" /> High
            </li>
          </ul>
        </div>

        {/* Privacy note */}
        <div className="absolute right-4 top-4 max-w-[180px] rounded-md border border-border bg-card/90 px-3 py-2 backdrop-blur-sm">
          <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Your location
          </p>
          <p className="mt-1 text-[11px] leading-tight">
            Obfuscated to a 500 m radius. Not stored beyond 24 hours.
          </p>
        </div>
      </div>
    </section>
  );
}
