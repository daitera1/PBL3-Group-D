export type Congestion = "low" | "moderate" | "high";
export type Confidence = "high" | "medium" | "low";
export type WaitCategory = "A&E Wait" | "Clinic Queue" | "Appointment Availability";
export type FacilityType = "Clinic" | "General Hospital" | "Emergency Hospital" | "Specialty Center";
export type LanguageSupport =
  | "Fully Bilingual Staff"
  | "Basic Communication Available"
  | "Translation Service Available"
  | "No Verified Language Support";

export interface LanguageEntry {
  language: string;
  level: LanguageSupport;
}

export interface Hospital {
  id: string;
  name: string;
  facilityType: FacilityType;
  address: string;
  area: string;
  description: string;
  distanceMiles: number;
  specialties: string[];
  departments: string[];
  insurance: string[];
  languages: LanguageEntry[];
  languagesVerifiedOn: string;
  // Wait prediction
  waitCategory: WaitCategory;
  waitLow: number;
  waitHigh: number;
  congestion: Congestion;
  confidence: Confidence;
  // For map positioning, as percentages over the map image
  mapX: number;
  mapY: number;
  // Synthetic predicted busy hours, 0..23 -> 0..100
  busyHours: number[];
  // Anonymous reviews
  reviewSummary: string;
  reviewCount: number;
  rating: number;
  // Visit prep
  documents: string[];
  arrivalInstructions: string;
  // Cold start case
  coldStart?: boolean;
}

const baseBusy = [
  18, 12, 8, 6, 6, 10, 22, 38, 55, 68, 74, 72,
  70, 65, 60, 58, 62, 70, 76, 72, 60, 48, 36, 26,
];

function shiftBusy(offset: number, gain = 1) {
  return baseBusy.map((v) => Math.max(4, Math.min(100, Math.round(v * gain + offset))));
}

export const hospitals: Hospital[] = [
  {
    id: "st-judes-urgent-care",
    name: "St. Jude's Urgent Care",
    facilityType: "Clinic",
    address: "14 Marsham Street, Westminster SW1P 4LH",
    area: "Westminster",
    description:
      "Walk-in urgent care clinic for minor injuries, fevers and routine assessments. Pediatric trained staff on every shift.",
    distanceMiles: 1.2,
    specialties: ["Minor Injuries", "Pediatrics", "General Practice"],
    departments: ["Walk-in Triage", "Pediatric Bay", "Minor Procedures", "Pharmacy"],
    insurance: ["NHS", "Bupa", "AXA Health", "Vitality"],
    languages: [
      { language: "English", level: "Fully Bilingual Staff" },
      { language: "Japanese", level: "Translation Service Available" },
      { language: "Tagalog", level: "Basic Communication Available" },
    ],
    languagesVerifiedOn: "22 Oct 2024",
    waitCategory: "Clinic Queue",
    waitLow: 12,
    waitHigh: 20,
    congestion: "low",
    confidence: "high",
    mapX: 38,
    mapY: 52,
    busyHours: shiftBusy(-10, 0.9),
    reviewSummary:
      "Patients consistently note efficient triage, calm waiting area and friendly pediatric staff.",
    reviewCount: 184,
    rating: 4.6,
    documents: ["Photo ID", "NHS number (if known)", "List of current medications"],
    arrivalInstructions:
      "Enter via the Marsham Street entrance. Check in at the self-service kiosk before taking a seat in Bay A.",
  },
  {
    id: "central-general-hospital",
    name: "Central General Hospital",
    facilityType: "General Hospital",
    address: "210 Euston Road, NW1 2DA",
    area: "Camden",
    description:
      "Mid-size NHS general hospital with adult A&E, outpatient clinics and a busy diagnostics department.",
    distanceMiles: 3.4,
    specialties: ["A&E", "Internal Medicine", "Diagnostics", "Orthopedics"],
    departments: ["A&E", "Outpatients", "Imaging", "Maternity"],
    insurance: ["NHS", "AXA Health", "Aviva"],
    languages: [
      { language: "English", level: "Fully Bilingual Staff" },
      { language: "Mandarin", level: "Translation Service Available" },
      { language: "Korean", level: "Translation Service Available" },
    ],
    languagesVerifiedOn: "08 Oct 2024",
    waitCategory: "A&E Wait",
    waitLow: 45,
    waitHigh: 65,
    congestion: "moderate",
    confidence: "medium",
    mapX: 52,
    mapY: 41,
    busyHours: shiftBusy(10, 1.05),
    reviewSummary:
      "Patients describe thorough care but variable A&E waits, especially in the late afternoon.",
    reviewCount: 612,
    rating: 3.9,
    documents: ["Photo ID", "GP referral letter (if any)", "Insurance details"],
    arrivalInstructions:
      "Report to the A&E reception inside the main Euston Road entrance. Bring water and a phone charger.",
  },
  {
    id: "victoria-memorial",
    name: "Victoria Memorial Hospital",
    facilityType: "Emergency Hospital",
    address: "9 Victoria Embankment, EC4Y 0HJ",
    area: "City of London",
    description:
      "Major emergency hospital handling complex trauma and round-the-clock acute admissions.",
    distanceMiles: 0.8,
    specialties: ["A&E", "Trauma", "Cardiology", "Stroke Unit"],
    departments: ["A&E", "Trauma Bay", "ICU", "Imaging"],
    insurance: ["NHS"],
    languages: [
      { language: "English", level: "Fully Bilingual Staff" },
      { language: "Filipino", level: "Basic Communication Available" },
    ],
    languagesVerifiedOn: "01 Sep 2024",
    waitCategory: "A&E Wait",
    waitLow: 95,
    waitHigh: 130,
    congestion: "high",
    confidence: "medium",
    mapX: 64,
    mapY: 58,
    busyHours: shiftBusy(25, 1.1),
    reviewSummary:
      "Clinicians are well-regarded; the trade-off is long waits during peak demand windows.",
    reviewCount: 1284,
    rating: 3.7,
    documents: ["Photo ID", "List of current medications", "Next-of-kin contact"],
    arrivalInstructions:
      "Emergency entrance is on the south side near the Embankment. Reception will direct you to the appropriate bay.",
  },
  {
    id: "thames-pediatric-clinic",
    name: "Thames Pediatric Clinic",
    facilityType: "Specialty Center",
    address: "62 Tooley Street, SE1 2TF",
    area: "Southwark",
    description:
      "Specialist outpatient pediatric clinic with translation services and multilingual reception.",
    distanceMiles: 2.1,
    specialties: ["Pediatrics", "Allergy", "Developmental Assessment"],
    departments: ["Pediatric Outpatients", "Allergy Testing", "Family Consultations"],
    insurance: ["NHS", "Bupa", "Cigna"],
    languages: [
      { language: "English", level: "Fully Bilingual Staff" },
      { language: "Japanese", level: "Fully Bilingual Staff" },
      { language: "Korean", level: "Basic Communication Available" },
      { language: "Mandarin", level: "Translation Service Available" },
      { language: "Filipino", level: "Translation Service Available" },
    ],
    languagesVerifiedOn: "30 Oct 2024",
    waitCategory: "Appointment Availability",
    waitLow: 25,
    waitHigh: 35,
    congestion: "low",
    confidence: "high",
    mapX: 58,
    mapY: 70,
    busyHours: shiftBusy(-5, 0.8),
    reviewSummary:
      "Highlighted for genuinely multilingual staff and calm, child-friendly consultation rooms.",
    reviewCount: 246,
    rating: 4.8,
    documents: [
      "Child's photo ID or red book",
      "List of allergies and medications",
      "Recent test results, if any",
    ],
    arrivalInstructions:
      "Use the Tooley Street main door and take the lift to floor 2. Reception speaks English and Japanese.",
  },
  {
    id: "kings-cross-walk-in",
    name: "King's Cross Walk-in Centre",
    facilityType: "Clinic",
    address: "5 Pentonville Road, N1 9HZ",
    area: "Islington",
    description:
      "Local NHS walk-in for low-acuity care, minor wound dressings and routine prescriptions.",
    distanceMiles: 2.7,
    specialties: ["Minor Injuries", "General Practice"],
    departments: ["Walk-in", "Pharmacy"],
    insurance: ["NHS"],
    languages: [
      { language: "English", level: "Fully Bilingual Staff" },
      { language: "Mandarin", level: "Basic Communication Available" },
    ],
    languagesVerifiedOn: "18 Sep 2024",
    waitCategory: "Clinic Queue",
    waitLow: 30,
    waitHigh: 45,
    congestion: "moderate",
    confidence: "medium",
    mapX: 44,
    mapY: 32,
    busyHours: shiftBusy(0, 1),
    reviewSummary:
      "Reliable for everyday minor complaints; expect a busier afternoon stretch around 4–6pm.",
    reviewCount: 158,
    rating: 4.1,
    documents: ["Photo ID", "Prescription details (if renewing)"],
    arrivalInstructions:
      "Enter at Pentonville Road. Take a numbered ticket from the dispenser by the door.",
  },
  {
    id: "evelina-specialty-clinic",
    name: "Evelina Specialty Clinic",
    facilityType: "Specialty Center",
    address: "Lambeth Palace Road, SE1 7EH",
    area: "Lambeth",
    description:
      "Newly opened specialty annexe — limited live data so predictions fall back to historical averages.",
    distanceMiles: 2.4,
    specialties: ["Cardiology", "Dermatology"],
    departments: ["Cardiology Outpatients", "Dermatology"],
    insurance: ["NHS", "Bupa"],
    languages: [{ language: "English", level: "Fully Bilingual Staff" }],
    languagesVerifiedOn: "14 Oct 2024",
    waitCategory: "Appointment Availability",
    waitLow: 0,
    waitHigh: 0,
    congestion: "moderate",
    confidence: "low",
    mapX: 50,
    mapY: 80,
    busyHours: shiftBusy(-2, 0.9),
    reviewSummary: "Too few public reviews so far. Treat published wait times as indicative only.",
    reviewCount: 9,
    rating: 4.2,
    documents: ["Photo ID", "GP referral letter"],
    arrivalInstructions:
      "Enter via Lambeth Palace Road and report to the specialty annexe desk on the ground floor.",
    coldStart: true,
  },
];

export function getHospital(id: string): Hospital | undefined {
  return hospitals.find((h) => h.id === id);
}

export const ALL_SPECIALTIES = Array.from(
  new Set(hospitals.flatMap((h) => h.specialties)),
).sort();

export const ALL_LANGUAGES = Array.from(
  new Set(hospitals.flatMap((h) => h.languages.map((l) => l.language))),
).sort();

export const SUPPORTED_UI_LANGUAGES = [
  { code: "en", label: "English" },
  { code: "ja", label: "日本語" },
  { code: "fil", label: "Filipino" },
  { code: "zh", label: "中文" },
  { code: "ko", label: "한국어" },
] as const;
export type UiLangCode = (typeof SUPPORTED_UI_LANGUAGES)[number]["code"];

export function congestionLabel(c: Congestion): string {
  switch (c) {
    case "low":
      return "Low";
    case "moderate":
      return "Moderate";
    case "high":
      return "High";
  }
}

export function confidenceLabel(c: Confidence): string {
  switch (c) {
    case "high":
      return "High";
    case "medium":
      return "Medium";
    case "low":
      return "Low";
  }
}

export function shouldWarn(h: Hospital): boolean {
  if (h.coldStart) return true;
  if (h.confidence === "low") return true;
  // > 60 min midpoint
  return (h.waitLow + h.waitHigh) / 2 > 60;
}

export type Priority = "fastest" | "closest";

export interface RecommendationInput {
  priority: Priority;
  preferredLanguage?: string;
  preferredSpecialty?: string;
  loadBalanceFactor?: Record<string, number>; // hospital id -> 0..1 visit-intent share
}

export interface Ranked {
  hospital: Hospital;
  score: number;
  rationale: string;
}

export function rankHospitals(
  list: Hospital[],
  input: RecommendationInput,
): Ranked[] {
  const { priority, preferredLanguage, preferredSpecialty, loadBalanceFactor = {} } = input;

  return list
    .map((h) => {
      const waitMid = h.coldStart ? 60 : (h.waitLow + h.waitHigh) / 2;
      const waitScore = Math.max(0, 100 - waitMid);
      const distScore = Math.max(0, 100 - h.distanceMiles * 15);
      const congScore = h.congestion === "low" ? 100 : h.congestion === "moderate" ? 60 : 25;
      const specMatch =
        preferredSpecialty && h.specialties.includes(preferredSpecialty) ? 25 : 0;
      const langMatch =
        preferredLanguage &&
        h.languages.some(
          (l) =>
            l.language === preferredLanguage &&
            l.level !== "No Verified Language Support",
        )
          ? 20
          : 0;
      const loadPenalty = (loadBalanceFactor[h.id] ?? 0) * 35;

      const base =
        priority === "fastest"
          ? waitScore * 0.55 + congScore * 0.2 + distScore * 0.1
          : distScore * 0.55 + waitScore * 0.2 + congScore * 0.1;

      const score = base + specMatch + langMatch - loadPenalty;

      const reasons: string[] = [];
      if (priority === "fastest" && waitMid < 30) reasons.push("short predicted wait");
      if (priority === "closest" && h.distanceMiles < 1.5) reasons.push("close to you");
      if (h.congestion === "low") reasons.push("low current congestion");
      if (specMatch) reasons.push(`matches ${preferredSpecialty}`);
      if (langMatch) reasons.push(`supports ${preferredLanguage}`);
      if (loadPenalty > 10) reasons.push("alternative to over-directed sites");
      if (reasons.length === 0) reasons.push("balanced wait and travel time");

      return {
        hospital: h,
        score,
        rationale: `Recommended because: ${reasons.join(", ")}.`,
      };
    })
    .sort((a, b) => b.score - a.score);
}

export function formatWait(h: Hospital): string {
  if (h.coldStart) return "—";
  return `${h.waitLow}–${h.waitHigh}`;
}
