import type { UiLangCode } from "./hospitals";

type Dict = Record<string, string>;

const en: Dict = {
  emergencyBadge: "Emergency Protocol",
  emergencyMessage: "Life-threatening? Call 999 immediately.",
  notDiagnostic: "CarePath is not a diagnostic tool. For emergencies, call 999.",
  nearbyFacilities: "Nearby facilities",
  fastest: "Fastest",
  closest: "Closest",
  allServices: "All services",
  recommended: "Recommended",
  estWait: "Est. wait",
  confidence: "Confidence",
  rationale: "Rationale",
  minutes: "min",
  liveMap: "Live facility network map",
  filterLanguage: "Filter by language",
  filterSpecialty: "Filter by specialty",
  any: "Any",
  reportWait: "Report current wait",
  reportThanks: "Thanks — your anonymous report has been queued for the data pipeline.",
  lowConfWarning:
    "The predicted wait time may be longer than expected or the prediction confidence is low. Would you still like to continue?",
  continueAnyway: "Continue anyway",
  cancel: "Cancel",
  viewDetails: "View details",
  back: "Back",
};

const ja: Dict = {
  emergencyBadge: "緊急時プロトコル",
  emergencyMessage: "命に関わる場合はすぐに999へ通報してください。",
  notDiagnostic: "CarePathは診断ツールではありません。緊急時は999へ。",
  nearbyFacilities: "近隣の医療施設",
  fastest: "最短",
  closest: "最寄り",
  allServices: "すべて",
  recommended: "おすすめ",
  estWait: "予測待ち時間",
  confidence: "信頼度",
  rationale: "理由",
  minutes: "分",
  liveMap: "施設ネットワークマップ",
  filterLanguage: "対応言語で絞り込み",
  filterSpecialty: "専門科で絞り込み",
  any: "指定なし",
  reportWait: "現在の待ち時間を報告",
  reportThanks: "ご報告ありがとうございます。匿名でデータパイプラインに送信されました。",
  lowConfWarning:
    "予測待ち時間が長くなる可能性があるか、信頼度が低いです。続行しますか?",
  continueAnyway: "続行する",
  cancel: "キャンセル",
  viewDetails: "詳細を見る",
  back: "戻る",
};

const fil: Dict = {
  emergencyBadge: "Emergency Protocol",
  emergencyMessage: "Banta sa buhay? Tumawag agad sa 999.",
  notDiagnostic: "Hindi diagnostic tool ang CarePath. Sa emergency, tumawag sa 999.",
  nearbyFacilities: "Mga pasilidad na malapit",
  fastest: "Pinakamabilis",
  closest: "Pinakamalapit",
  allServices: "Lahat",
  recommended: "Inirerekomenda",
  estWait: "Tantyang hintay",
  confidence: "Antas ng tiwala",
  rationale: "Dahilan",
  minutes: "min",
  liveMap: "Live na mapa ng pasilidad",
  filterLanguage: "I-filter ayon sa wika",
  filterSpecialty: "I-filter ayon sa specialty",
  any: "Kahit alin",
  reportWait: "I-ulat ang kasalukuyang hintay",
  reportThanks: "Salamat — naitala na nang anonymous ang iyong ulat.",
  lowConfWarning:
    "Maaaring mas matagal ang aktwal na hintay o mababa ang antas ng tiwala. Magpapatuloy ka pa rin?",
  continueAnyway: "Magpatuloy",
  cancel: "Kanselahin",
  viewDetails: "Tingnan ang detalye",
  back: "Bumalik",
};

const zh: Dict = {
  emergencyBadge: "紧急情况",
  emergencyMessage: "生命危险？请立即拨打999。",
  notDiagnostic: "CarePath 并非诊断工具。紧急情况请拨打999。",
  nearbyFacilities: "附近的医疗机构",
  fastest: "最快",
  closest: "最近",
  allServices: "全部",
  recommended: "推荐",
  estWait: "预计等待",
  confidence: "置信度",
  rationale: "推荐理由",
  minutes: "分钟",
  liveMap: "实时机构地图",
  filterLanguage: "按语言筛选",
  filterSpecialty: "按专科筛选",
  any: "不限",
  reportWait: "上报当前等待时间",
  reportThanks: "谢谢，您的匿名报告已加入数据流。",
  lowConfWarning: "实际等待可能更长，或预测置信度较低。仍要继续吗？",
  continueAnyway: "继续",
  cancel: "取消",
  viewDetails: "查看详情",
  back: "返回",
};

const ko: Dict = {
  emergencyBadge: "긴급 프로토콜",
  emergencyMessage: "생명이 위급한가요? 즉시 999로 전화하세요.",
  notDiagnostic: "CarePath는 진단 도구가 아닙니다. 응급상황은 999로 연락하세요.",
  nearbyFacilities: "주변 의료시설",
  fastest: "가장 빠름",
  closest: "가장 가까움",
  allServices: "전체",
  recommended: "추천",
  estWait: "예상 대기",
  confidence: "신뢰도",
  rationale: "추천 이유",
  minutes: "분",
  liveMap: "실시간 시설 지도",
  filterLanguage: "언어로 필터",
  filterSpecialty: "전문과로 필터",
  any: "전체",
  reportWait: "현재 대기시간 신고",
  reportThanks: "감사합니다. 익명 신고가 데이터 파이프라인에 전송되었습니다.",
  lowConfWarning:
    "예상 대기시간이 길어질 수 있거나 신뢰도가 낮습니다. 계속하시겠습니까?",
  continueAnyway: "계속하기",
  cancel: "취소",
  viewDetails: "상세 보기",
  back: "뒤로",
};

const tables: Record<UiLangCode, Dict> = { en, ja, fil, zh, ko };

export function t(lang: string, key: string): string {
  const dict = tables[(lang as UiLangCode) ?? "en"] ?? en;
  return dict[key] ?? en[key] ?? key;
}
